package com.example.myapplication

import android.app.Dialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.icu.util.Calendar
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.shawnlin.numberpicker.NumberPicker

class seat_ordering : AppCompatActivity() {

    private var selectedTime: String? = null
    private var selectedPaymentMethod: String? = null
    private var selectedSeats: Int = 1
    private var selectTypeFood:String?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_seat_ordering)

        val timeButton = findViewById<Button>(R.id.time_btn)
        val payingMethodButton = findViewById<Button>(R.id.PayingMethod)
        val showDetailsButton = findViewById<Button>(R.id.show_data_btn)
        val numberPicker = findViewById<NumberPicker>(R.id.number_picker)
        val veganFoodSelect=findViewById<RadioGroup>(R.id.VeganRadio)

        veganFoodSelect.setOnCheckedChangeListener { group , checkedId ->
            when (checkedId){
                R.id.vegan->{
                    selectTypeFood= getString(R.string.vegan_in_reservetion)
                    Toast.makeText(this ,"Selected:Vegan meal",Toast.LENGTH_SHORT)
                }
                R.id.NotVegan->{
                    selectTypeFood= getString(R.string.not_vegan_in_reservetion)
                    Toast.makeText(this ,"Selected:not Vegan meal",Toast.LENGTH_SHORT)
                }
            }
        }
        numberPicker.setOnValueChangedListener { _, _, newValue ->
            selectedSeats = newValue
        }

        timeButton.setOnClickListener {
            val current_time = Calendar.getInstance()
            val startHour = current_time.get(Calendar.HOUR_OF_DAY)
            val startMinute = current_time.get(Calendar.MINUTE)
            TimePickerDialog(
                this,
                { _, hourOfDay, minute ->
                    selectedTime = "$hourOfDay:$minute"
                    timeButton.text = "Selected Time: $selectedTime"
                },
                startHour, startMinute, true
            ).show()
        }
        payingMethodButton.setOnClickListener {
            val dialogBinding = layoutInflater.inflate(R.layout.dialog_layout, null)
            val myDialog = Dialog(this)
            myDialog.setContentView(dialogBinding)
            myDialog.setCancelable(true)
            myDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            myDialog.show()

            val cashButton = dialogBinding.findViewById<Button>(R.id.cash_btn)
            val creditButton = dialogBinding.findViewById<Button>(R.id.credit_btn)

            cashButton.setOnClickListener {
                selectedPaymentMethod = getString(R.string.cash)
                myDialog.dismiss()
            }

            creditButton.setOnClickListener {
                selectedPaymentMethod = getString(R.string.credit)
                myDialog.dismiss()
            }
        }
        showDetailsButton.setOnClickListener {
            val time = selectedTime ?: getString(R.string.not_selected)
            val paymentMethod = selectedPaymentMethod ?: getString(R.string.not_selected_payment)

            // Use `getString()` for formatted messages
            val messageTime = getString(R.string.selected_time, time)
            val messagePayment = getString(R.string.payment_method, paymentMethod)
            val messageSeats = getString(R.string.number_of_seats, selectedSeats)
            val messageMeal = getString(R.string.meal, selectTypeFood ?: getString(R.string.not_selected))

            val message = "$messageTime\n$messagePayment\n$messageSeats\n$messageMeal"

            AlertDialog.Builder(this)
                .setTitle(getString(R.string.order_details))
                .setMessage(message)
                .setPositiveButton(getString(R.string.confirm)) { dialog, _ ->
                    Toast.makeText(this, getString(R.string.order_confirmed), Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
                .setNegativeButton(getString(R.string.cancel)) { dialog, _ ->
                    Toast.makeText(this, getString(R.string.order_canceled), Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
                .show()
        }

        val blink =AnimationUtils.loadAnimation(applicationContext,R.anim.blink)
        val ReserveBtn =findViewById<Button>(R.id.show_data_btn)
        ReserveBtn.startAnimation(blink)
    }
}
