package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.app_new_layout)
        val seatsBtn = findViewById<Button>(R.id.seats_button)
        seatsBtn.setOnClickListener {
            val intent = Intent(this, seat_ordering::class.java)
            startActivity(intent)
        }
        val menuBtn = findViewById<Button>(R.id.menu_bt)
        menuBtn.setOnClickListener {
            val intent = Intent(this, menu::class.java)
            startActivity(intent)
        }
        val SwitchBackground=findViewById<Switch>(R.id.switch1)
        val bounce=AnimationUtils.loadAnimation(applicationContext,R.anim.bounce)
        val zoom=AnimationUtils.loadAnimation(applicationContext,R.anim.zoom_in_out)
        val welcome = findViewById<TextView>(R.id.welcome)
        val background = findViewById<LinearLayout>(R.id.background)
        SwitchBackground.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked)
            {
                background.setBackgroundResource(R.drawable.second_background)
            }
            else{
                background.setBackgroundResource(R.drawable.resta)

            }
        }
        welcome.startAnimation(zoom)
        menuBtn.startAnimation(bounce)
        seatsBtn.startAnimation(bounce)
    }
}
