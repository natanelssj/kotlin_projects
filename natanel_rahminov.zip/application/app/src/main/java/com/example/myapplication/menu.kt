package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.view.animation.AnimationUtils

class menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()


        setContentView(R.layout.activity_menu)
        val veganSwitch = findViewById<Button>(R.id.switcher)
        veganSwitch.setOnClickListener {
            val intent = Intent(this, vegan_menu::class.java)
            startActivity(intent)
        }

        val meatballBtn = findViewById<ImageButton>(R.id.meatball)
        meatballBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.meatball), "$10.00",
                getString(R.string.detail_meatball))
        }
        val steakBtn = findViewById<ImageButton>(R.id.steak)
        steakBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.steak), "$25.00", getString(R.string.steak_detail))
        }

        val mojitoBtn = findViewById<ImageButton>(R.id.mojito_drink)
        mojitoBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.Mojito), "$7.00", getString(R.string.mojito_detail))
        }

        val whiskyBtn = findViewById<ImageButton>(R.id.whisky_drink)
        whiskyBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.whisky), "$15.00",
                getString(R.string.whisky_detail))
        }
        val slidLeft=AnimationUtils.loadAnimation(applicationContext,R.anim.slide_in_left)
        val flip =AnimationUtils.loadAnimation(applicationContext,R.anim.flip)

        veganSwitch.startAnimation(slidLeft)
        whiskyBtn.startAnimation(slidLeft)
        mojitoBtn.startAnimation(slidLeft)
        steakBtn.startAnimation(slidLeft)
        meatballBtn.startAnimation(slidLeft)
        veganSwitch.startAnimation(flip)
    }

    private fun showDetailsDialog(itemName: String, price: String, description: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(itemName)

        val priceDescription = getString(R.string.price_description, price, description)
        builder.setMessage(priceDescription)

        builder.setPositiveButton(getString(R.string.ok)) { dialog, _ ->
            dialog.dismiss()
        }
        builder.create().show()
    }




}
