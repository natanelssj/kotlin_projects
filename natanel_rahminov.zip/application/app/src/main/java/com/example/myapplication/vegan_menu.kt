package com.example.myapplication

import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class vegan_menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vegan_menu)
        val rotate = AnimationUtils.loadAnimation(applicationContext,R.anim.rotate)
        val spicy=findViewById<CheckBox>(R.id.checkBox)
        val fruitSaladBtn = findViewById<ImageButton>(R.id.fruit_salad)
        val background=findViewById<LinearLayout>(R.id.vegan_menu)
        fruitSaladBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.vegan_fruit_salad), "$12.00",
                getString(R.string.a_refreshing_mix_of_seasonal_fruits))
        }
        spicy.setOnCheckedChangeListener{_,isChecked->
            if(isChecked)
            {
                background.setBackgroundResource(R.drawable.spicy_menu)

            }
            else{
                background.setBackgroundResource(R.drawable.menu_pic)
            }
        }
        val veganMealBtn = findViewById<ImageButton>(R.id.meal)
        veganMealBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.vegan_meal), "$18.00",
                getString(R.string.vegan_meal_details))
        }

        val mojitoBtn = findViewById<ImageButton>(R.id.mojito_drink)
        mojitoBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.vegan_mojito), "$8.00",
                getString(R.string.mojito_details))
        }

        val whiskyBtn = findViewById<ImageButton>(R.id.whisky_drink)
        whiskyBtn.setOnClickListener {
            showDetailsDialog(getString(R.string.vegan_whisky), "$20.00",
                getString(R.string.whisky_details))
        }
        fruitSaladBtn.startAnimation(rotate)
        veganMealBtn.startAnimation(rotate)
    }
    private fun showDetailsDialog(itemName: String, price: String, description: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(itemName)
        val priceDescription = getString(R.string.price_description, price, description)
        builder.setMessage(priceDescription)
        builder.setPositiveButton(getString(R.string.ok)) { dialog, _ ->
            dialog.dismiss()
        }
        builder.create().show()
    }
}
