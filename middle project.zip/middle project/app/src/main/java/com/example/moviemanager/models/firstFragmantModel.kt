package com.example.moviemanager.models

data class FirstFragmentModel(
    val image: Int,
    val characterName: String,
    val characterDescription: String
)
