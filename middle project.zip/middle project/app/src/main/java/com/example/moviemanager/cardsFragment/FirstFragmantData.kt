package com.example.moviemanager.cardsFragment

data class FirstFragmentData(val title: String, val description: String, val photo: String?)

object ItemManager {
    val items: MutableList<FirstFragmentData> = mutableListOf()

    fun add(item: FirstFragmentData) {
        items.add(item)
    }

    fun remove(index: Int) {
        if (index in items.indices) {
            items.removeAt(index)
        } else {
            throw IndexOutOfBoundsException("Index $index is out of bounds for the item list.")
        }
    }
}
