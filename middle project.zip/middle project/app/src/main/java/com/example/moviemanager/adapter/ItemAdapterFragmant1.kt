package com.example.moviemanager.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.moviemanager.cardsFragment.FirstFragmentData
import com.example.moviemanager.databinding.CardForFirstFragmentBinding

class ItemAdapterFragment1(private val items: List<FirstFragmentData>) :
    RecyclerView.Adapter<ItemAdapterFragment1.ItemViewHolder>() {

    class ItemViewHolder(private val binding: CardForFirstFragmentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: FirstFragmentData) {
            binding.itemTitle.text = item.title
            binding.itemDescription.text = item.description
            //binding.itemImage.drawable=item.photo
             if (item.photo != null) {
             }
        }
    }

    // Inflate layout and create ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=
        ItemViewHolder(CardForFirstFragmentBinding.inflate(LayoutInflater.from(parent.context)))

    // Bind data to ViewHolder
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int)=
        holder.bind(items[position])

    // Return the total number of items
    override fun getItemCount(): Int {
        return items.size
    }
}
